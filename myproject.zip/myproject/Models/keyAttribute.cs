﻿using System;

namespace myproject.Models
{
    internal class keyAttribute : Attribute
    {
    }
}