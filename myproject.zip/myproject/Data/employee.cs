﻿namespace myproject.Data
{
    internal class employee
    {
    }
}